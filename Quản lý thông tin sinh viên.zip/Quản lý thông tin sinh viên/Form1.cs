﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quản_lý_thông_tin_sinh_viên
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        { 
        try
        {
            StudentBDContext context = new StudentBDContext();
            List<Faculty> listFalcultys = context.Faculties.ToList();
            List<Student> listStudent = context.Students.ToList();
            FillFalcultyCombobox(listFalcultys);
            BindGrid(listStudent);
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message);
        }
    }
    private void FillFalcultyCombobox(List<Faculty> listFalcultys)
        {
            this.cmbFaculty.DataSource = listFalcultys;
            this.cmbFaculty.DisplayMember = "FacultyName";
            this.cmbFaculty.ValueMember = "FacultyID";
        }
        private void BindGrid(List<Student> listStudent)
        {
            dgvStudent.Rows.Clear();
            foreach (var item in listStudent)
            {
                int index = dgvStudent.Rows.Add();
                dgvStudent.Rows[index].Cells[0].Value = item.StudentID;
                dgvStudent.Rows[index].Cells[1].Value = item.FullName;
                dgvStudent.Rows[index].Cells[2].Value = item.Faculty.FacultyName;
                dgvStudent.Rows[index].Cells[3].Value = item.AverageScore;
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            try
            {
                StudentBDContext context = new StudentBDContext();
                Student newStudent = new Student
                {
                    StudentID = txtStudentID.Text,
                    FullName = txtFullName.Text,
                    FacultyID = (int)cmbFaculty.SelectedValue,
                    AverageScore = double.Parse(txtAverageScore.Text)
                };
                context.Students.Add(newStudent);
                context.SaveChanges();
                RefreshGrid();
                MessageBox.Show("Thêm sinh viên thành công!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            try
            {
                StudentBDContext context = new StudentBDContext();
                string studentID = txtStudentID.Text;
                Student student = context.Students.FirstOrDefault(s => s.StudentID == studentID);

                if (student != null)
                {
                    student.FullName = txtFullName.Text;
                    student.FacultyID = (int)cmbFaculty.SelectedValue;
                    student.AverageScore = double.Parse(txtAverageScore.Text);
                    context.SaveChanges();
                    RefreshGrid();
                    MessageBox.Show("Cập nhật thông tin sinh viên thành công!");
                }
                else
                {
                    MessageBox.Show("Không tìm thấy sinh viên!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnxoa_Click(object sender, EventArgs e)
        {
            try
            {
                StudentBDContext context = new StudentBDContext();
                string studentID = txtStudentID.Text;
                Student student = context.Students.FirstOrDefault(s => s.StudentID == studentID);

                if (student != null)
                {
                    context.Students.Remove(student);
                    context.SaveChanges();
                    RefreshGrid();
                    MessageBox.Show("Xóa sinh viên thành công!");
                }
                else
                {
                    MessageBox.Show("Không tìm thấy sinh viên!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
            private void RefreshGrid()
        {
            StudentBDContext context = new StudentBDContext();
            List<Student> listStudent = context.Students.ToList();
            BindGrid(listStudent);
            ClearInputFields();
        }
        private void ClearInputFields()
        {
            txtStudentID.Clear();
            txtFullName.Clear();
            txtAverageScore.Clear();
            cmbFaculty.SelectedIndex = -1;
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgvStudent_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = dgvStudent.Rows[e.RowIndex];
                txtStudentID.Text = selectedRow.Cells[0].Value.ToString();
                txtFullName.Text = selectedRow.Cells[1].Value.ToString();
                cmbFaculty.Text = selectedRow.Cells[2].Value.ToString();
                txtAverageScore.Text = selectedRow.Cells[3].Value.ToString();
            }
        }
    }
}
